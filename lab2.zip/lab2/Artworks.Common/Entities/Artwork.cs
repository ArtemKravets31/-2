namespace Artworks.Common.Entities;

// Абстрактний клас "Мистецький твір"
public abstract class Artwork
{
    public Guid Id { get; set; } = Guid.CreateVersion7();
    public string Title { get; set; }
    public string Artist { get; set; }
    public int YearOfCreation { get; set; }

    public Artwork(string title, string artist, int yearOfCreation)
    {
        Title = title;
        Artist = artist;
        YearOfCreation = yearOfCreation;
    }

    // Абстрактний метод — реалізується в кожному виді мистецтва по-різному
    public abstract void Display();

    // Загальна інформація
    public virtual void ShowInfo()
    {
        Console.WriteLine($"Назва: {Title}, Художник: {Artist}");
    }
}