namespace Artworks.Common.Entities;

// Цифрове мистецтво
public class DigitalArt : Artwork
{
    public string SoftwareUsed { get; set; }

    public DigitalArt(string title, string artist, int yearOfCreation, string softwareUsed)
        : base(title, artist, yearOfCreation)
    {
        SoftwareUsed = softwareUsed;
    }

    public override void Display()
    {
        Console.WriteLine($"Цифрове мистецтво: \"{Title}\" створене в {SoftwareUsed} від {Artist}.");
    }

    public static DigitalArt Create()
    {
        return new DigitalArt("Art", "Artist", Random.Shared.Next(1000, 2025), "Krita");
    }
}