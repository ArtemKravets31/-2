namespace Artworks.Common.Entities;

// Живопис
public class Painting : Artwork
{
    public string Medium { get; set; } // Наприклад, олія, акрил, акварель

    public Painting(string title, string artist, int yearOfCreation, string medium)
        : base(title, artist, yearOfCreation)
    {
        Medium = medium;
    }

    public override void Display()
    {
        Console.WriteLine($"Живопис: \"{Title}\" технікою {Medium} від {Artist}.");
    }
    
    public static Painting Create()
    {
        return new Painting("Painting", "Artist", Random.Shared.Next(1000, 2025), "Olive");
    }
}