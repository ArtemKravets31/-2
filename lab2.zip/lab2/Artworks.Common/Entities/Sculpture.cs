namespace Artworks.Common.Entities;

// Скульптура
public class Sculpture : Artwork
{
    public string Material { get; set; } // Наприклад, мармур, бронза

    public Sculpture(string title, string artist, int yearOfCreation, string material)
        : base(title, artist, yearOfCreation)
    {
        Material = material;
    }

    public override void Display()
    {
        Console.WriteLine($"Скульптура: \"{Title}\" з {Material}, автор — {Artist}.");
    }
    
    public static Painting Create()
    {
        return new Painting("Sculpture", "Artist", Random.Shared.Next(1000, 2025), "Bronze");
    }
}