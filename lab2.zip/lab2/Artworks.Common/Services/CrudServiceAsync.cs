using System.Collections;
using System.Collections.Concurrent;
using Artworks.Common.Contracts;
using Newtonsoft.Json;

namespace Artworks.Common.Services;

public class CrudServiceAsync<T> : ICrudServiceAsync<T>
{
    private readonly Func<T, Guid> _idGetter;
    private ConcurrentDictionary<Guid, T> _values = new();
    private SemaphoreSlim _semaphore = new(1);

    public CrudServiceAsync(Func<T, Guid> idGetter)
    {
        _idGetter = idGetter;
    }

    public Task<bool> CreateAsync(T element)
    {
        return Task.FromResult(_values.TryAdd(_idGetter(element), element));
    }

    public Task<T> ReadAsync(Guid id)
    {
        return Task.FromResult(_values.TryGetValue(id, out T element) ? element : default);
    }

    public Task<IEnumerable<T>> ReadAllAsync()
    {
        return Task.FromResult(_values.Values.AsEnumerable());
    }

    public Task<IEnumerable<T>> ReadAllAsync(int page, int amount)
    {
        return Task.FromResult(_values
            .Values
            .Skip(page * amount)
            .Take(amount)
            .AsEnumerable());
    }

    public Task<bool> UpdateAsync(T element)
    {
        return Task.FromResult(_values.TryUpdate(_idGetter(element), element, element));
    }

    public Task<bool> RemoveAsync(T element)
    {
        return Task.FromResult(_values.Remove(_idGetter(element), out _));
    }

    public async Task<bool> SaveAsync(string path)
    {
        try
        {
            await _semaphore.WaitAsync();
            var json = JsonConvert.SerializeObject(_values);
            await File.WriteAllTextAsync(path, json);
            return true;
        }
        catch (Exception exception)
        {
            Console.WriteLine(exception.Message);
            return false;
        }
        finally
        {
            _semaphore.Release();
        }
    }

    public async Task<bool> LoadAsync(string path)
    {
        try
        {
            await _semaphore.WaitAsync();
            var json = await File.ReadAllTextAsync(path);
            _values = JsonConvert.DeserializeObject<ConcurrentDictionary<Guid, T>>(json)!;
            return true;
        }
        catch (Exception exception)
        {
            Console.WriteLine(exception.Message);
            return false;
        }
        finally
        {
            _semaphore.Release();
        }
    }

    public IEnumerator<T> GetEnumerator()
    {
        return _values.Values.GetEnumerator();
    }

    IEnumerator IEnumerable.GetEnumerator()
    {
        return GetEnumerator();
    }
}