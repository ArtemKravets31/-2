﻿// See https://aka.ms/new-console-template for more information

using Artworks.Common.Services;
using Artworks.Common.Entities;

var service = new CrudServiceAsync<Painting>(x => x.Id);

Parallel.For(0, 1000, async i =>
{
    await service.CreateAsync(Painting.Create());
});

var paintings = (await service.ReadAllAsync()).ToList();

foreach (var painting in paintings)
{
    painting.Display();
}

Console.WriteLine($"Count {paintings.Count}");
Console.WriteLine($"Max Year {paintings.Max(x => x.YearOfCreation)}");
Console.WriteLine($"Min Year {paintings.Min(x => x.YearOfCreation)}");
Console.WriteLine($"Average Year {paintings.Average(x => x.YearOfCreation)}");