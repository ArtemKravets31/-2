﻿using Artworks.Common.Entities;
using Artworks.Common.Services;

namespace Artworks.Tests;

public class CrudServiceAsyncTests
{
    private CrudServiceAsync<Painting> GetService() =>
        new CrudServiceAsync<Painting>(p => p.Id);

    private Painting CreatePainting(string title, string artist) =>
        new Painting(title, artist, Random.Shared.Next(1000, 2025), "Olive");

    [Fact]
    public async Task CreateAndRead_ShouldReturnSameElement()
    {
        var service = GetService();
        var painting = CreatePainting("Starry Night", "Van Gogh");

        var created = await service.CreateAsync(painting);
        var retrieved = await service.ReadAsync(painting.Id);

        Assert.True(created);
        Assert.NotNull(retrieved);
        Assert.Equal("Starry Night", retrieved.Title);
    }

    [Fact]
    public async Task ReadAll_ShouldReturnAllElements()
    {
        var service = GetService();
        var paintings = new[]
        {
            CreatePainting("A", "A1"),
            CreatePainting("B", "B1"),
            CreatePainting("C", "C1")
        };

        foreach (var p in paintings)
            await service.CreateAsync(p);

        var all = await service.ReadAllAsync();

        Assert.Equal(3, all.Count());
    }

    [Fact]
    public async Task ReadAll_WithPagination_ShouldReturnCorrectPage()
    {
        var service = GetService();
        for (int i = 0; i < 10; i++)
            await service.CreateAsync(CreatePainting($"Painting {i}", "Artist"));

        var page = await service.ReadAllAsync(page: 1, amount: 3);
        Assert.Equal(3, page.Count());
    }

    [Fact]
    public async Task UpdateAsync_ShouldModifyElement()
    {
        var service = GetService();
        var painting = CreatePainting("Old", "Someone");
        await service.CreateAsync(painting);

        painting.Title = "Updated";
        var updated = await service.UpdateAsync(painting);
        var result = await service.ReadAsync(painting.Id);

        Assert.True(updated);
        Assert.Equal("Updated", result.Title);
    }

    [Fact]
    public async Task RemoveAsync_ShouldRemoveElement()
    {
        var service = GetService();
        var painting = CreatePainting("Removable", "A");

        await service.CreateAsync(painting);
        var removed = await service.RemoveAsync(painting);
        var result = await service.ReadAsync(painting.Id);

        Assert.True(removed);
        Assert.Null(result);
    }

    [Fact]
    public async Task SaveAndLoad_ShouldPersistData()
    {
        var service = GetService();
        var painting = CreatePainting("Persistent", "Artist");

        await service.CreateAsync(painting);

        var path = Path.Combine(Path.GetTempPath(), "paintings_test.json");

        try
        {
            var saved = await service.SaveAsync(path);
            Assert.True(saved);

            // Create a new instance to test Load
            var loadedService = GetService();
            var loaded = await loadedService.LoadAsync(path);
            var result = await loadedService.ReadAsync(painting.Id);

            Assert.True(loaded);
            Assert.NotNull(result);
            Assert.Equal(painting.Title, result.Title);
        }
        finally
        {
            if (File.Exists(path))
                File.Delete(path);
        }
    }
}